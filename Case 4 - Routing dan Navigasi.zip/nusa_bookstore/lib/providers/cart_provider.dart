import 'package:flutter/material.dart';
import '../models/book.dart';

class CartItem {
  final Book book;
  int quantity;

  CartItem({
    required this.book,
    this.quantity = 1,
  });
}

class CartProvider extends ChangeNotifier {
  final Map<String, CartItem> _items = {};

  Map<String, CartItem> get items => _items;

  // Menghitung jumlah seluruh buku di keranjang
  int get totalItems {
    int total = 0;
    _items.forEach((key, cartItem) {
      total += cartItem.quantity;
    });
    return total;
  }

  // Menghitung total harga seluruh buku
  int get totalPrice {
    int total = 0;
    _items.forEach((key, cartItem) {
      total += cartItem.book.price * cartItem.quantity;
    });
    return total;
  }

  // Menambahkan buku atau menambah jumlah jika sudah ada
  void addItem(Book book) {
    if (_items.containsKey(book.id)) {
      _items[book.id]!.quantity += 1;
    } else {
      _items[book.id] = CartItem(book: book, quantity: 1);
    }
    notifyListeners();
  }

  // Mengurangi jumlah atau menghapus buku jika jumlah mencapai 0
  void removeItem(String bookId) {
    if (!_items.containsKey(bookId)) return;

    if (_items[bookId]!.quantity > 1) {
      _items[bookId]!.quantity -= 1;
    } else {
      _items.remove(bookId);
    }
    notifyListeners();
  }

  // Mengosongkan keranjang
  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}