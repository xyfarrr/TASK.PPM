import 'package:flutter/material.dart';

class Book {
  final String id;
  final String title;
  final String author;
  final int price;
  final IconData icon;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.price,
    required this.icon,
  });
}

// Data contoh minimal 4 buku
final List<Book> dummyBooks = [
  Book(
    id: 'b1',
    title: 'Laskar Pelangi',
    author: 'Andrea Hirata',
    price: 85000,
    icon: Icons.auto_stories,
  ),
  Book(
    id: 'b2',
    title: 'Bumi Manusia',
    author: 'Pramoedya Ananta Toer',
    price: 115000,
    icon: Icons.menu_book,
  ),
  Book(
    id: 'b3',
    title: 'Filosofi Teras',
    author: 'Henry Manampiring',
    price: 98000,
    icon: Icons.psychology,
  ),
  Book(
    id: 'b4',
    title: 'Negeri 5 Menara',
    author: 'Ahmad Fuadi',
    price: 89000,
    icon: Icons.import_contacts,
  ),
  Book(
    id: 'b5',
    title: 'Laut Bercerita',
    author: 'Leila S. Chudori',
    price: 105000,
    icon: Icons.book,
  ),
];