# Nusa Bookstore

Aplikasi toko buku sederhana menggunakan Flutter dan State Management Provider.

## Screenshot Aplikasi

### 1. Halaman Katalog Buku (Dark Mode)
![Halaman Katalog](screenshoot/home.png)

### 2. Halaman Katalog Buku (Light Mode)
![Light Mode](screenshoot/light%20mode.png)

### 3. Badge Jumlah Keranjang
![Tambah Keranjang](screenshoot/tambah%20keranjang.png)

### 4. Halaman Keranjang & Total Harga
![Keranjang Belanja](screenshoot/keranjang.png)

### 5. SnackBar Setelah Checkout
![Checkout](screenshoot/checkout.png)