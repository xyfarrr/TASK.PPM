# NusaBookstore - State Management (Provider)
**Mata Kuliah:** Pemrograman Perangkat Mobile (IF31033)
**Program Studi:** S1 Teknik Informatika - Universitas Nusa Putra
**Dosen Pengampu:** Nugraha, M.Kom / Yulhan Wahyudin, M.Kom
**Nama:** Siti Farda Sya'bani  
**NIM:** 20240040109  
**Kelas:** TI 24 M  

---

## Dokumentasi Tangkapan Layar (Screenshots)

Berikut adalah dokumentasi hasil pengujian antarmuka (*UI*) dan reaktivitas *State Management* menggunakan package `Provider` pada aplikasi **NusaBookstore**[cite: 1]:

### 1. Halaman Utama Katalog Buku — Light Mode & Badge Kosong (`0`)
![Halaman Katalog Light Mode](Screenshoot/menu.png)

* **Deskripsi Pengujian:**
  * Aplikasi pertama kali dijalankan dalam kondisi default `ThemeMode.light` yang dikelola oleh `ThemeProvider`[cite: 1].
  * Menampilkan daftar katalog buku kampus dalam widget `Card` dan `ListView`[cite: 1].
  * Pada `AppBar`, widget `Consumer<CartProvider>` menampilkan ikon keranjang belanja dengan badge bernilai **`0`** karena belum ada buku yang ditambahkan[cite: 1].

---

### 2. Halaman Katalog Buku — Dark Mode
![Halaman Katalog Dark Mode](Screenshoot/dark%20mode.png)

* **Deskripsi Pengujian:**
  * Pengguna menekan tombol toggle tema pada `AppBar` yang memanggil `context.read<ThemeProvider>().toggleTheme()`[cite: 1].
  * `ThemeProvider` mengubah nilai `_themeMode` menjadi `ThemeMode.dark` dan memanggil `notifyListeners()`[cite: 1].
  * Seluruh warna latar belakang, kartu buku, dan teks pada aplikasi berubah seketika secara konsisten di semua layar[cite: 1].

---

### 3. Reaktivitas Badge Keranjang Saat Item Ditambahkan
![Tambah Item ke Keranjang](Screenshoot/masukan%20keranjang.png)

* **Deskripsi Pengujian:**
  * Pengguna menekan tombol **"Tambah ke Keranjang"** pada item buku[cite: 1].
  * Aksi ini memanggil `context.read<CartProvider>().addItem(book)` dan mengeksekusi `notifyListeners()`[cite: 1].
  * Hanya widget `Badge` yang dibungkus `Consumer<CartProvider>` di dalam `AppBar` yang di-rebuild untuk memperbarui angka total item secara *real-time*, tanpa merender ulang seluruh daftar katalog buku[cite: 1].

---

### 4. Halaman Keranjang Belanja (`CartScreen`) & Kalkulasi Total Harga
![Halaman Keranjang Belanja](Screenshoot/keranjang%20belanja.png)

* **Deskripsi Pengujian:**
  * Halaman `CartScreen` menggunakan `context.watch<CartProvider>()` untuk memantau perubahan data keranjang secara reaktif[cite: 1].
  * Pengguna dapat menekan tombol **`+`** (`addItem`) atau **`-`** (`removeItem`) untuk mengubah kuantitas masing-masing buku secara langsung[cite: 1].
  * Subtotal per buku, **Total Item**, dan **Total Pembayaran** (format Rupiah) otomatis diperbarui setiap kali kuantitas berubah[cite: 1].

---

### 5. Konfirmasi Checkout & Pengosongan Keranjang (`clearCart`)
![Konfirmasi Checkout Berhasil](Screenshoot/checkout.png)

* **Deskripsi Pengujian:**
  * Pengguna menekan tombol **"Checkout / Bayar"** pada panel ringkasan pembayaran[cite: 1].
  * Sistem memanggil `context.read<CartProvider>().clearCart()` yang menghapus seluruh daftar item dan mereset badge keranjang kembali ke angka `0`[cite: 1].
  * Muncul notifikasi `SnackBar` konfirmasi bahwa pembayaran telah berhasil diproses[cite: 1].

---

## Struktur Direktori Kode Sumber
```text
lib/
├── models/
│   └── book.dart               # Model data Book & dummy catalog[cite: 1]
├── providers/
│   ├── cart_provider.dart      # Logika bisnis keranjang (ChangeNotifier)[cite: 1]
│   └── theme_provider.dart     # Logika pergantian tema Light/Dark Mode[cite: 1]
├── screens/
│   ├── catalog_screen.dart     # UI Katalog Buku & AppBar Badge (Consumer)[cite: 1]
│   └── cart_screen.dart        # UI Keranjang Belanja & Checkout (context.watch)[cite: 1]
└── main.dart                   # Konfigurasi root MultiProvider & MaterialApp[cite: 1]