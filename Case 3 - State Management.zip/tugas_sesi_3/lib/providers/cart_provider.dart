import 'package:flutter/foundation.dart';
import '../models/book.dart';

class CartItem {
  final Book book;
  int quantity;

  CartItem({
    required this.book,
    this.quantity = 1,
  });
}

class CartProvider with ChangeNotifier {
  // Menggunakan Map dengan key book.id agar pencarian & update O(1)
  final Map<String, CartItem> _items = {};

  Map<String, CartItem> get items => {..._items};

  // Menghitung total seluruh kuantitas buku di keranjang
  int get totalItems {
    int total = 0;
    _items.forEach((key, cartItem) {
      total += cartItem.quantity;
    });
    return total;
  }

  // Menghitung total harga keseluruhan
  double get totalPrice {
    double total = 0.0;
    _items.forEach((key, cartItem) {
      total += cartItem.book.price * cartItem.quantity;
    });
    return total;
  }

  // Menambah buku ke keranjang atau menambah kuantitas jika sudah ada
  void addItem(Book book) {
    if (_items.containsKey(book.id)) {
      _items.update(
        book.id,
        (existingItem) => CartItem(
          book: existingItem.book,
          quantity: existingItem.quantity + 1,
        ),
      );
    } else {
      _items.putIfAbsent(
        book.id,
        () => CartItem(book: book, quantity: 1),
      );
    }
    notifyListeners(); // Memberi tahu UI untuk melakukan rebuild selektif
  }

  // Mengurangi kuantitas atau menghapus item jika kuantitas tinggal 1
  void removeItem(String bookId) {
    if (!_items.containsKey(bookId)) return;

    if (_items[bookId]!.quantity > 1) {
      _items.update(
        bookId,
        (existingItem) => CartItem(
          book: existingItem.book,
          quantity: existingItem.quantity - 1,
        ),
      );
    } else {
      _items.remove(bookId);
    }
    notifyListeners();
  }

  // Menghapus satu jenis buku sepenuhnya dari keranjang
  void removeSingleBookCompletely(String bookId) {
    _items.remove(bookId);
    notifyListeners();
  }

  // Mengosongkan keranjang (saat checkout)
  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}