import 'package:flutter/material.dart';

class Book {
  final String id;
  final String title;
  final String author;
  final double price;
  final IconData coverIcon;
  final Color coverColor;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.price,
    required this.coverIcon,
    required this.coverColor,
  });
}

// Data katalog buku dummy (Minimal 4 buku sesuai spesifikasi)
final List<Book> dummyBooks = [
  Book(
    id: 'BK-001',
    title: 'Pemrograman Perangkat Mobile dengan Flutter',
    author: 'Nugraha, M.Kom & Tim',
    price: 85000,
    coverIcon: Icons.phone_android_rounded,
    coverColor: Colors.blueAccent,
  ),
  Book(
    id: 'BK-002',
    title: 'Arsitektur Clean Code & Design Patterns',
    author: 'Robert C. Martin',
    price: 120000,
    coverIcon: Icons.architecture_rounded,
    coverColor: Colors.teal,
  ),
  Book(
    id: 'BK-003',
    title: 'Algoritma & Struktur Data Lanjut',
    author: 'Yulhan Wahyudin, M.Kom',
    price: 95000,
    coverIcon: Icons.account_tree_rounded,
    coverColor: Colors.deepPurple,
  ),
  Book(
    id: 'BK-004',
    title: 'Basis Data Terdistribusi & Cloud',
    author: 'Dr. Andi Pratama',
    price: 110000,
    coverIcon: Icons.cloud_done_rounded,
    coverColor: Colors.orangeAccent,
  ),
  Book(
    id: 'BK-005',
    title: 'Keamanan Jaringan & Kriptografi Modern',
    author: 'Rina Kusuma, M.T.',
    price: 105000,
    coverIcon: Icons.security_rounded,
    coverColor: Colors.indigo,
  ),
];